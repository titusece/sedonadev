//
// Copyright (c) 2007 Tridium, Inc.
// Licensed under the Academic Free License version 3.0
//
// History:
//   4 Jun 07  Brian Frank  Creation
//

package sedona;

/**
 * Obj is the Java representation of a Sedona base Obj.
 */
public abstract class Obj
{
}

